package com.simplecoding.simpledms.exam;

public class B {

/*
@Controller
public class DeptController {

 // 서비스 가져오기
private final DeptService deptService;

    // 생성자 주입
    @Autowired
    public DeptController(DeptService deptService) {
        this.deptService = deptService;
    }

*/
}
