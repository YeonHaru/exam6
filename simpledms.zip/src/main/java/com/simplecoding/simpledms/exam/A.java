package com.simplecoding.simpledms.exam;

public class A {

    //    DI : Dependency Injection 의존성 주입
// 객체가 필요로 하는 다른 객체를 스스로 생성하는 대신 외부에서 주입하는 방식
//    생성자 주입, 세터 주입, 필드 주입 등이 있음

//    IOC Inversion of Control 제어의 역전
//    객체의 생성, 초기화, 소멸 등 제어 흐름을 개발자가 아닌 컨테이너가 담당하는 개념

//    AOP Aspect Oriented Programming 관점 지향 프로그래밍
//    로깅, 트랜잭션, 보안 등 핵심 로직과 상관없는 공통기능을 핵심 로직에서 분리하여 모듈화하는 방법
}
