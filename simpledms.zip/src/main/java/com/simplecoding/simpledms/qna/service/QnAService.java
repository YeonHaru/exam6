package com.simplecoding.simpledms.qna.service;

import com.simplecoding.simpledms.common.ErrorMsg;
import com.simplecoding.simpledms.common.MapStruct;
import com.simplecoding.simpledms.qna.dto.QnADto;
import com.simplecoding.simpledms.qna.entity.QnA;
import com.simplecoding.simpledms.qna.repository.QnARepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class QnAService {
    private final QnARepository qnARepository;
    private final MapStruct mapStruct;
    private final ErrorMsg errorMsg;

    public Page<QnADto> selectQnAList(String searchKeyword, Pageable pageable) {
        Page<QnA> page = qnARepository.selectQnAList(searchKeyword, pageable);
        return page.map(data -> mapStruct.toDto(data));
    }
}
