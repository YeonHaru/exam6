package com.simplecoding.simpledms.qna.repository;

import com.simplecoding.simpledms.qna.entity.QnA;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface QnARepository extends JpaRepository<QnA, Long> {

    @Query(value = "select q from QnA q\n" +
    "where q.question like %:searchKeyword%")
    Page<QnA> selectQnAList(@Param("searchKeyword") String searchKeyword,
                            Pageable pageable);
}
