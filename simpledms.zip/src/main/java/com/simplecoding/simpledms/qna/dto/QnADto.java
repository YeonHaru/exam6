package com.simplecoding.simpledms.qna.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class QnADto {
    private Long id;
    private String question;
    private String questioner;
    private String answer;
    private String answerer;
}
