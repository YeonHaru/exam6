package com.simplecoding.simpledms.qna.controller;

import com.simplecoding.simpledms.qna.dto.QnADto;
import com.simplecoding.simpledms.qna.service.QnAService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequiredArgsConstructor
@Log4j2
@Controller
public class QnAController {
    private final QnAService qnAService;

    @GetMapping("/qna")
    public String selectQnAList(@RequestParam(defaultValue = "") String searchKeyword,
                                @PageableDefault(page = 0, size = 3) Pageable pageable,
                                Model model) {
        Page<QnADto> pages = qnAService.selectQnAList(searchKeyword, pageable);
        log.info(pages.getTotalPages());
        model.addAttribute("qnas", pages.getContent());
        model.addAttribute("pages", pages);

        return "qna/qna_all";
    }
}
