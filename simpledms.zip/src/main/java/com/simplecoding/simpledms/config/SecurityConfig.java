package com.simplecoding.simpledms.config;

// 스프링 시큐리티 설정 파일

import jakarta.servlet.DispatcherType;
import jakarta.servlet.ServletException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import java.io.IOException;

// 자바파일을 설정파일로 사용할 수 있게 하는 어노테이션: 예) appliction.properties 파일처럼 사용
@Configuration
// 스프링 시큐리티를 활성화하는 어노테이션
@EnableWebSecurity
public class SecurityConfig {

    //    과거) 스프링: DB 패스워드는 암호화 해야합니다.(암호화 라이브러리 설치)
//    지금) 스프링부트: 암호화 라이브러리가 포함됨(스프링 시큐리티 안에 있음)

//    목적: 암호화 메소드
    @Bean   // IOC: 예) @Service 등 유사
    public PasswordEncoder  passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

//    목적: 인증, 권한 설정 메소드
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        authorize(권한 관리)
        http.authorizeHttpRequests(auth->auth
                .dispatcherTypeMatchers(DispatcherType.FORWARD).permitAll() //JSP 태그 중에 redirect 태그를 허용하겠다!
                .dispatcherTypeMatchers(DispatcherType.INCLUDE).permitAll() //JSP 태그 중에 include  태그를 허용하겠다!
                .requestMatchers("/auth/**", "/", "/errors", "/css/**", "/image/**", "/js/**").permitAll() // 해당 url을 쓰는 인터넷 주소는 전부 통과 (로그인 없이 접근 가능)
                .requestMatchers("/admin/**").hasAuthority("ROLE_ADMIN")
                .anyRequest().authenticated() // 위의 url을 사용하는 것 외에는 로그인 필요
        );
    }
}
