package com.simplecoding.simpledms.filedb.dto;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FileDbDto {
//    엔티티 클래스 보고 만들기
//    성능을 생각했을 때 이미지(fileData)는 빼는 것이 좋음 (why? 화면에 필요한 것은 다운로드 url만 있으면 됨)

    private String uuid;
    private String fileTitle;
    private String fileContent;
    private String fileUrl;

//    생성자 (매개변수 2개)
    public FileDbDto(String fileTitle, String fileContent) {
        this.fileTitle = fileTitle;
        this.fileContent = fileContent;
    }
}
